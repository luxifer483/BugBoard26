// Verifica le API Express su PostgreSQL reale, usando soltanto uno schema temporaneo dedicato.
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID, createHmac } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { once } from 'node:events';
import { spawn } from 'node:child_process';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import sharp from 'sharp';

if (!process.env.TEST_DATABASE_URL) {
  throw new Error('Set TEST_DATABASE_URL to a disposable PostgreSQL database, or run backend/test-docker.ps1.');
}
process.env.NODE_ENV = 'test';
process.env.DB_URL = process.env.TEST_DATABASE_URL;
process.env.TEST_DB_SCHEMA = `bugboard_test_${randomUUID().replaceAll('-', '')}`;
process.env.JWT_SECRET = 'node-test-secret-with-more-than-thirty-two-bytes';
process.env.JWT_ISSUER = 'bugboard26';
process.env.JWT_AUDIENCE = 'bugboard26-frontend';

const { default: app } = await import('../src/app.js');
const { sequelize, User, Project, Membership, Issue, IssueImage, Comment, Notification } = await import('../src/models/index.js');
const { createToken } = await import('../src/services/auth.js');
const { bootstrapAdmin } = await import('../src/services/bootstrap.js');
const { initializeSchema } = await import('../src/services/schema.js');
const schema = process.env.TEST_DB_SCHEMA;
const initialSql = await readFile(new URL('../sql/001-initial.sql', import.meta.url), 'utf8');
const hash = await bcrypt.hash('Password123!', 4);
const png = await sharp({ create: { width: 8, height: 6, channels: 3, background: '#346799' } }).png().toBuffer();
let server, base;
let admin, member, reviewer, outsider, project;
let adminToken, memberToken, reviewerToken, outsiderToken;

// Installa lo stesso SQL di Spring nello schema isolato, mai nel database di sviluppo.
async function applySql(sql = initialSql) {
  await sequelize.transaction(async (transaction) => {
    await sequelize.query("SELECT set_config('search_path', $schema, true)", { bind: { schema }, transaction });
    await sequelize.query(sql, { transaction });
  });
}

async function runInitializer(targetSchema) {
  const child = spawn(process.execPath, ['scripts/init-db.js'], { cwd: new URL('..', import.meta.url),
    env: { ...process.env, TEST_DB_SCHEMA: targetSchema }, stdio: ['ignore', 'pipe', 'pipe'] });
  let output = '';
  child.stderr.on('data', (chunk) => { output += chunk; });
  const [code] = await once(child, 'exit');
  assert.equal(code, 0, output);
}

before(async () => {
  await sequelize.authenticate();
  await sequelize.getQueryInterface().createSchema(schema);
  await initializeSchema();
  server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}/api`;
});

after(async () => {
  if (server) await new Promise((resolve) => server.close(resolve));
  // Rimuove solo lo schema con il nome casuale generato da questa esecuzione.
  await sequelize.getQueryInterface().dropSchema(schema);
  await sequelize.close();
});

beforeEach(async () => {
  const suffix = randomUUID();
  [admin, member, reviewer, outsider] = await Promise.all(['ADMIN', 'USER', 'USER', 'USER'].map((role, index) =>
    User.create({ fullName: `User ${index}`, email: `${index}-${suffix}@example.test`, passwordHash: hash, role })));
  [adminToken, memberToken, reviewerToken, outsiderToken] = [admin, member, reviewer, outsider].map((user) => createToken(user).token);
  project = await Project.create({ name: 'Test project', description: 'Disposable verification' });
  await Membership.bulkCreate([{ projectId: project.id, userId: member.id }, { projectId: project.id, userId: reviewer.id }]);
});

// Invia una vera richiesta HTTP senza simulare controller, autenticazione o database.
async function call(method, path, token, input, expected = 200, headers = {}) {
  const multipart = input instanceof FormData;
  const response = await fetch(base + path, { method,
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(input !== undefined && !multipart ? { 'Content-Type': 'application/json' } : {}), ...headers },
    ...(input === undefined ? {} : { body: multipart ? input : JSON.stringify(input) }) });
  const content = await response.text();
  assert.equal(response.status, expected, `${method} ${path}: ${content}`);
  return content ? JSON.parse(content) : null;
}

function payload(assigneeId = null) {
  return { projectId: Number(project.id), title: 'Test issue', description: 'Description', type: 'BUG', priority: 'HIGH', assigneeId };
}

async function createIssue(token = adminToken, assigneeId = null) {
  return call('POST', '/issues', token, payload(assigneeId), 201);
}

// Prepara una vera richiesta multipart, come il selettore di file del browser.
function imageUpload(data = png, type = 'image/png', values = payload()) {
  const form = new FormData();
  for (const [name, value] of Object.entries(values)) {
    if (value !== null && value !== undefined) form.append(name, String(value));
  }
  if (data !== null) form.append('image', new Blob([data], { type }), 'screenshot');
  return form;
}

test('PNG, JPEG and WebP images are saved with the issue and downloaded through an authenticated endpoint', async () => {
  for (const format of ['png', 'jpeg', 'webp']) {
    const bytes = await sharp(png).toFormat(format).toBuffer();
    const type = `image/${format}`;
    const issue = await call('POST', '/issues', memberToken, imageUpload(bytes, type), 201);
    assert.deepEqual(issue.image, { contentType: type });
    assert.equal((await call('GET', `/issues/${issue.id}`, reviewerToken)).image.contentType, type);
    const listed = (await call('GET', `/projects/${project.id}/issues`, memberToken)).items.find((item) => item.id === issue.id);
    assert.deepEqual(listed.image, { contentType: type });
    const response = await fetch(`${base}/issues/${issue.id}/image`, { headers: { Authorization: `Bearer ${reviewerToken}` } });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('content-type'), type);
    assert.equal(response.headers.get('cache-control'), 'private, no-store');
    assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
    const downloaded = Buffer.from(await response.arrayBuffer());
    const metadata = await sharp(downloaded).metadata();
    assert.equal(metadata.format, format);
    assert.equal(metadata.width, 8);
    assert.equal(metadata.height, 6);
    assert.deepEqual((await IssueImage.findByPk(issue.id)).data, downloaded);
  }
});

test('the image is optional for both JSON and multipart requests', async () => {
  const { priority, ...withoutPriority } = payload();
  assert.equal(priority, 'HIGH');
  for (const input of [withoutPriority, imageUpload(null, 'image/png', withoutPriority)]) {
    const issue = await call('POST', '/issues', memberToken, input, 201);
    assert.equal(issue.image, null);
    assert.equal(issue.priority, null);
    assert.equal(await IssueImage.findByPk(issue.id), null);
    assert.equal((await call('GET', `/issues/${issue.id}/image`, memberToken, undefined, 404)).code, 'NOT_FOUND');
  }
});

test('image uploads and downloads require login and project access, including after membership revocation', async () => {
  const before = await Issue.count();
  await call('POST', '/issues', null, imageUpload(), 401);
  await call('POST', '/issues', outsiderToken, imageUpload(), 403);
  assert.equal(await Issue.count(), before);
  const issue = await call('POST', '/issues', memberToken, imageUpload(), 201);
  await call('GET', `/issues/${issue.id}/image`, null, undefined, 401);
  await call('GET', `/issues/${issue.id}/image`, outsiderToken, undefined, 403);
  const adminResponse = await fetch(`${base}/issues/${issue.id}/image`, { headers: { Authorization: `Bearer ${adminToken}` } });
  assert.equal(adminResponse.status, 200);
  await adminResponse.arrayBuffer();
  await call('DELETE', `/projects/${project.id}/members/${member.id}`, adminToken, undefined, 204);
  await call('GET', `/issues/${issue.id}/image`, memberToken, undefined, 403);
});

test('fake, corrupt, unsupported and mismatched image files do not create issues or images', async () => {
  const before = await Issue.count();
  const images = await IssueImage.count();
  for (const [data, type] of [[Buffer.from('not an image'), 'image/png'], [png, 'image/jpeg'],
    [Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8"/>'), 'image/png'],
    [png.subarray(0, 40), 'image/png'], [Buffer.alloc(0), 'image/png'], [png, 'image/gif'], [png, 'text/html']]) {
    assert.equal((await call('POST', '/issues', memberToken, imageUpload(data, type), 400)).code, 'INVALID_IMAGE');
  }
  assert.equal(await Issue.count(), before);
  assert.equal(await IssueImage.count(), images);
});

test('images over 5 MB and requests with multiple or unexpected files are rejected before saving', async () => {
  const before = await Issue.count();
  assert.equal((await call('POST', '/issues', memberToken, imageUpload(Buffer.alloc(5 * 1024 * 1024 + 1)), 413)).code,
    'IMAGE_TOO_LARGE');
  const multiple = imageUpload();
  multiple.append('image', new Blob([png], { type: 'image/png' }), 'second.png');
  await call('POST', '/issues', memberToken, multiple, 400);
  const wrongField = imageUpload(null);
  wrongField.append('attachment', new Blob([png], { type: 'image/png' }), 'unexpected.png');
  await call('POST', '/issues', memberToken, wrongField, 400);
  assert.equal(await Issue.count(), before);
});

test('image decoding enforces the pixel limit and removes private metadata', async () => {
  const large = await sharp({ create: { width: 4001, height: 4000, channels: 3, background: '#ffffff' } }).png().toBuffer();
  await call('POST', '/issues', memberToken, imageUpload(large), 400);
  const tagged = await sharp(png).withMetadata({ exif: { IFD0: { Artist: 'Private author' } } }).png().toBuffer();
  assert.ok((await sharp(tagged).metadata()).exif);
  const issue = await call('POST', '/issues', memberToken, imageUpload(tagged), 201);
  const metadata = await sharp((await IssueImage.findByPk(issue.id)).data).metadata();
  assert.equal(metadata.exif, undefined);
});

test('invalid issue fields and notification failures leave no orphan image or partial issue', async () => {
  const issues = await Issue.count();
  const images = await IssueImage.count();
  const savedProject = await Project.findByPk(project.id);
  await call('POST', '/issues', memberToken, imageUpload(png, 'image/png', { ...payload(), title: ' ' }), 400);
  const original = Notification.create;
  Notification.create = async () => { throw new Error('Simulated image issue notification failure'); };
  try {
    await call('POST', '/issues', memberToken, imageUpload(png, 'image/png', payload(Number(reviewer.id))), 500);
  } finally { Notification.create = original; }
  assert.equal(await Issue.count(), issues);
  assert.equal(await IssueImage.count(), images);
  assert.equal((await Project.findByPk(project.id)).updatedAt.toISOString(), savedProject.updatedAt.toISOString());
});

test('repeated initialization preserves the existing image bytes and issue data', async () => {
  const issue = await call('POST', '/issues', memberToken, imageUpload(), 201);
  const saved = await IssueImage.findByPk(issue.id);
  await initializeSchema();
  await initializeSchema();
  assert.deepEqual((await IssueImage.findByPk(issue.id)).data, saved.data);
  assert.equal((await Issue.findByPk(issue.id)).title, issue.title);
});

test('login normalizes email and returns a signed token and safe account', async () => {
  const result = await call('POST', '/auth/login', null, { email: admin.email.toUpperCase(), password: 'Password123!' });
  assert.equal(result.user.id, Number(admin.id));
  assert.equal(result.user.role, 'ADMIN');
  assert.equal(result.user.passwordHash, undefined);
  assert.equal(result.user.password, undefined);
  assert.ok(Date.parse(result.expiresAt) > Date.now());
  assert.equal((await call('GET', '/users/me', result.token)).id, Number(admin.id));
});

test('wrong password and unknown email return the same failure', async () => {
  for (const email of [admin.email, 'missing@example.test']) {
    const error = await call('POST', '/auth/login', null, { email, password: 'wrong' }, 401);
    assert.equal(error.code, 'INVALID_CREDENTIALS');
  }
});

test('login rejects a multibyte password beyond the BCrypt byte limit', async () => {
  const error = await call('POST', '/auth/login', null, { email: admin.email, password: 'é'.repeat(40) }, 401);
  assert.equal(error.code, 'INVALID_CREDENTIALS');
});

test('existing BCrypt 2a hashes and Spring-shaped HS256 tokens remain usable', async () => {
  await member.update({ passwordHash: hash.replace('$2b$', '$2a$') });
  const session = await call('POST', '/auth/login', null, { email: member.email, password: 'Password123!' });
  assert.equal(session.user.id, Number(member.id));
  const encode = (value) => Buffer.from(JSON.stringify(value)).toString('base64url');
  const issued = Math.floor(Date.now() / 1000);
  const unsigned = `${encode({ alg: 'HS256' })}.${encode({ sub: String(member.id), iss: 'bugboard26',
    aud: ['bugboard26-frontend'], iat: issued, exp: issued + 3600 })}`;
  const legacy = `${unsigned}.${createHmac('sha256', process.env.JWT_SECRET).update(unsigned).digest('base64url')}`;
  assert.equal((await call('GET', '/users/me', legacy)).id, Number(member.id));
});

test('missing, altered, expired and wrongly signed tokens are rejected', async () => {
  for (const token of [undefined, `${adminToken}invalid`, jwt.sign({ sub: String(admin.id) }, 'wrong-key')]) {
    assert.equal((await call('GET', '/projects', token, undefined, 401)).code, 'UNAUTHORIZED');
  }
  for (const overrides of [{ expiresIn: -3600 }, { issuer: 'other' }, { audience: 'other' }]) {
    const token = jwt.sign({}, process.env.JWT_SECRET, { algorithm: 'HS256', subject: String(admin.id),
      issuer: 'bugboard26', audience: 'bugboard26-frontend', expiresIn: 3600, ...overrides });
    await call('GET', '/users/me', token, undefined, 401);
  }
});

test('current user and privileges are reloaded from the database on each request', async () => {
  await call('GET', '/users', memberToken, undefined, 403);
  await member.update({ role: 'ADMIN' });
  await call('GET', '/users', memberToken);
  await member.update({ role: 'USER' });
  await call('GET', '/users', memberToken, undefined, 403);
});

test('admin creates users with hashed passwords and unique normalized email', async () => {
  const input = { fullName: 'New user', email: `NEW-${randomUUID()}@example.test`, password: 'Password123!', role: 'USER' };
  const result = await call('POST', '/users', adminToken, input, 201);
  assert.equal(result.email, input.email.toLowerCase());
  const saved = await User.findByPk(result.id);
  assert.notEqual(saved.passwordHash, input.password);
  assert.ok(await bcrypt.compare(input.password, saved.passwordHash));
  assert.equal((await call('POST', '/users', adminToken, input, 409)).code, 'EMAIL_EXISTS');
});

test('normal users cannot enumerate accounts or create users or projects', async () => {
  await call('GET', '/users', memberToken, undefined, 403);
  await call('POST', '/users', memberToken, { fullName: 'Escalation', email: 'x@example.test', password: 'Password123!', role: 'ADMIN' }, 403);
  await call('POST', '/projects', memberToken, { name: 'Forbidden', description: 'Description' }, 403);
});

test('user validation rejects blank names, invalid email, roles and BCrypt truncation', async () => {
  const valid = { fullName: 'User', email: `${randomUUID()}@example.test`, password: 'Password123!', role: 'USER' };
  for (const invalid of [{ fullName: ' ' }, { email: 'invalid' }, { password: 'short' },
    { password: 'é'.repeat(40) }, { role: 'QA' }]) {
    const error = await call('POST', '/users', adminToken, { ...valid, ...invalid }, 400);
    assert.ok(error.code);
    assert.equal(error.path, '/api/users');
  }
});

test('project creation also creates the administrator membership', async () => {
  const created = await call('POST', '/projects', adminToken, { name: ' New project ', description: ' Description ' }, 201);
  assert.equal(created.name, 'New project');
  assert.equal(created.memberCount, 1);
  assert.equal(created.totalIssues, 0);
  const members = await call('GET', `/projects/${created.id}/members`, adminToken);
  assert.equal(members.items[0].userId, Number(admin.id));
});

test('project lists and direct access enforce membership; admin access is global', async () => {
  const other = await Project.create({ name: 'Private project', description: 'Description' });
  const visible = await call('GET', '/projects', memberToken);
  assert.deepEqual(visible.items.map((item) => item.id), [Number(project.id)]);
  await call('GET', `/projects/${other.id}`, memberToken, undefined, 403);
  await call('GET', `/projects/${other.id}/members`, memberToken, undefined, 403);
  await call('GET', `/projects/${other.id}`, adminToken);
});

test('membership creation, duplicate detection and immediate revocation work', async () => {
  await call('POST', `/projects/${project.id}/members`, memberToken, { userId: Number(outsider.id) }, 403);
  await call('POST', `/projects/${project.id}/members`, adminToken, { userId: Number(outsider.id) }, 201);
  assert.equal((await call('POST', `/projects/${project.id}/members`, adminToken, { userId: Number(outsider.id) }, 409)).code, 'ALREADY_MEMBER');
  await call('GET', `/projects/${project.id}`, outsiderToken);
  await call('DELETE', `/projects/${project.id}/members/${outsider.id}`, memberToken, undefined, 403);
  await call('DELETE', `/projects/${project.id}/members/${outsider.id}`, adminToken, undefined, 204);
  await call('GET', `/projects/${project.id}`, outsiderToken, undefined, 403);
});

test('malformed and out-of-range identifiers are handled without SQL errors', async () => {
  for (const value of ['not-a-number', '0', '-1', '1.5', '9223372036854775808']) {
    await call('GET', `/projects/${value}`, adminToken, undefined, 400);
  }
  await call('GET', '/projects/9223372036854775807', adminToken, undefined, 404);
  await call('GET', '/issues/9223372036854775807', memberToken, undefined, 404);
});

test('CORS allows the frontend and PATCH, and rejects an unrelated origin', async () => {
  const allowed = await fetch(`${base}/issues/1/status`, { method: 'OPTIONS', headers: {
    Origin: 'http://localhost:5173', 'Access-Control-Request-Method': 'PATCH',
    'Access-Control-Request-Headers': 'authorization,content-type',
  } });
  assert.equal(allowed.status, 204);
  assert.equal(allowed.headers.get('access-control-allow-origin'), 'http://localhost:5173');
  assert.match(allowed.headers.get('access-control-allow-methods'), /PATCH/);
  await call('OPTIONS', '/projects', null, undefined, 403, { Origin: 'https://untrusted.example',
    'Access-Control-Request-Method': 'GET' });
});

test('member creates an issue while reporter, status and dates remain server controlled', async () => {
  const issue = await call('POST', '/issues', memberToken, { ...payload(Number(member.id)),
    reporter: { id: Number(admin.id) }, status: 'CLOSED', createdAt: '2000-01-01T00:00:00Z' }, 201);
  assert.equal(issue.reporter.id, Number(member.id));
  assert.equal(issue.status, 'TODO');
  assert.equal(issue.code, `BUG-26-${issue.id}`);
  assert.ok(!issue.createdAt.startsWith('2000'));
  assert.equal((await call('GET', '/notifications', memberToken)).unreadCount, 0);
});

test('all four issue types remain supported', async () => {
  for (const type of ['BUG', 'QUESTION', 'DOCUMENTATION', 'FEATURE']) {
    const issue = await call('POST', '/issues', memberToken, { ...payload(), type }, 201);
    assert.equal(issue.type, type);
  }
});

test('priority is optional and valid explicit priorities are preserved', async () => {
  const { priority, ...withoutPriority } = payload();
  assert.equal(priority, 'HIGH');
  for (const input of [withoutPriority, { ...withoutPriority, priority: null }]) {
    const issue = await call('POST', '/issues', memberToken, input, 201);
    assert.equal(issue.priority, null);
    assert.equal(issue.status, 'TODO');
    assert.equal((await call('GET', `/issues/${issue.id}`, memberToken)).priority, null);
    assert.equal((await Issue.findByPk(issue.id)).priority, null);
  }
  for (const value of ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']) {
    const issue = await call('POST', '/issues', memberToken, { ...withoutPriority, priority: value }, 201);
    assert.equal(issue.priority, value);
  }
});

test('invalid issue fields are rejected without writing rows', async () => {
  const before = await Issue.count();
  for (const invalid of [{ title: ' ' }, { description: 'x'.repeat(10001) }, { type: 'UNKNOWN' },
    { priority: '' }, { priority: false }, { priority: 0 }, { priority: {} },
    { priority: 'UNKNOWN' }, { projectId: -1 }, { assigneeId: true }]) {
    await call('POST', '/issues', memberToken, { ...payload(), ...invalid }, 400);
  }
  assert.equal(await Issue.count(), before);
});

test('assignee must belong to the project, including administrator accounts', async () => {
  for (const user of [outsider, admin]) {
    const error = await call('POST', '/issues', memberToken, payload(Number(user.id)), 400);
    assert.equal(error.code, 'ASSIGNEE_NOT_MEMBER');
  }
  await call('POST', '/issues', memberToken, payload(9223372036854775807n.toString()), 404);
});

test('outsiders cannot read or change issues and comments', async () => {
  const issue = await createIssue();
  for (const path of [`/projects/${project.id}/issues`, `/issues/${issue.id}`, `/issues/${issue.id}/comments`]) {
    await call('GET', path, outsiderToken, undefined, 403);
  }
  await call('POST', '/issues', outsiderToken, payload(), 403);
  await call('POST', `/issues/${issue.id}/comments`, outsiderToken, { content: 'intrusion' }, 403);
  await call('PATCH', `/issues/${issue.id}/status`, outsiderToken, { status: 'IN_PROGRESS' }, 403);
  await call('PATCH', `/issues/${issue.id}/assignee`, outsiderToken, { assigneeId: Number(member.id) }, 403);
  assert.equal((await call('GET', '/issues', outsiderToken)).totalCount, 0);
  assert.equal((await call('GET', '/issues', memberToken)).totalCount, 1);
});

test('only the assignee can update status, including when the reporter or an admin is a project member', async () => {
  await Membership.create({ projectId: project.id, userId: admin.id });
  const issue = await createIssue(memberToken, Number(reviewer.id));
  const savedIssue = await Issue.findByPk(issue.id);
  const savedProject = await Project.findByPk(project.id);
  const notifications = await Notification.count({ where: { issueId: issue.id } });
  for (const token of [memberToken, adminToken]) {
    for (const status of ['TODO', 'IN_PROGRESS', 'CLOSED']) {
      const error = await call('PATCH', `/issues/${issue.id}/status`, token,
        { status, assigneeId: Number(member.id) }, 403);
      assert.equal(error.code, 'NOT_ISSUE_ASSIGNEE');
    }
  }
  const unchanged = await Issue.findByPk(issue.id);
  assert.equal(unchanged.status, 'TODO');
  assert.equal(String(unchanged.assigneeId), String(reviewer.id));
  assert.equal(unchanged.updatedAt.toISOString(), savedIssue.updatedAt.toISOString());
  assert.equal((await Project.findByPk(project.id)).updatedAt.toISOString(), savedProject.updatedAt.toISOString());
  assert.equal(await Notification.count({ where: { issueId: issue.id } }), notifications);
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'IN_PROGRESS' });
});

test('unassigned issues cannot change status until an assignee is chosen', async () => {
  const issue = await createIssue(memberToken);
  for (const token of [memberToken, reviewerToken, adminToken]) {
    for (const status of ['TODO', 'IN_PROGRESS']) {
      assert.equal((await call('PATCH', `/issues/${issue.id}/status`, token, { status }, 403)).code,
        'NOT_ISSUE_ASSIGNEE');
    }
  }
  assert.equal((await Issue.findByPk(issue.id)).status, 'TODO');
  assert.equal(await Notification.count({ where: { issueId: issue.id } }), 0);
  await call('PATCH', `/issues/${issue.id}/assignee`, memberToken, { assigneeId: Number(reviewer.id) });
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'IN_PROGRESS' });
});

test('reassignment and unassignment immediately change who can update status', async () => {
  const issue = await createIssue(memberToken, Number(member.id));
  await call('PATCH', `/issues/${issue.id}/assignee`, memberToken, { assigneeId: Number(reviewer.id) });
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' }, 403);
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'IN_PROGRESS' });
  await call('PATCH', `/issues/${issue.id}/assignee`, reviewerToken, { assigneeId: null });
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'CLOSED' }, 403);
  await call('PATCH', `/issues/${issue.id}/assignee`, reviewerToken, { assigneeId: Number(member.id) });
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'IN_PROGRESS' }, 403);
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'CLOSED' }, 403);
  assert.equal((await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'CLOSED' })).status, 'CLOSED');
});

test('an administrator can change status when they are the assignee', async () => {
  await Membership.create({ projectId: project.id, userId: admin.id });
  const issue = await createIssue(memberToken, Number(admin.id));
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' }, 403);
  for (const status of ['IN_PROGRESS', 'CLOSED']) {
    assert.equal((await call('PATCH', `/issues/${issue.id}/status`, adminToken, { status })).status, status);
  }
  const feed = await call('GET', '/notifications', memberToken);
  assert.equal(feed.items.filter((item) => item.issueId === issue.id && /resolved/.test(item.message)).length, 1);
});

test('the assignee can advance status with the existing transitions and idempotency', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  assert.equal((await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'CLOSED' }, 409)).code, 'INVALID_STATUS_TRANSITION');
  for (const status of ['IN_PROGRESS', 'IN_PROGRESS', 'CLOSED', 'CLOSED']) {
    assert.equal((await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status })).status, status);
  }
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'TODO' }, 409);
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'OPEN' }, 400);
  assert.equal((await call('GET', '/notifications', adminToken)).unreadCount, 2);
  assert.equal((await call('GET', '/notifications', memberToken)).unreadCount, 1);
});

test('reassignment and unassignment are saved without duplicate notifications', async () => {
  const issue = await createIssue();
  for (let i = 0; i < 2; i++) {
    const result = await call('PATCH', `/issues/${issue.id}/assignee`, memberToken, { assigneeId: Number(reviewer.id) });
    assert.equal(result.assignee.id, Number(reviewer.id));
  }
  assert.equal((await call('GET', '/notifications', reviewerToken)).unreadCount, 1);
  await call('PATCH', `/issues/${issue.id}/assignee`, memberToken, { assigneeId: Number(outsider.id) }, 400);
  assert.equal((await call('PATCH', `/issues/${issue.id}/assignee`, memberToken, { assigneeId: null })).assignee, null);
  assert.equal((await call('GET', `/issues/${issue.id}`, adminToken)).assignee, null);
});

test('comments use the authenticated author, are ordered and validate content', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  const first = await call('POST', `/issues/${issue.id}/comments`, reviewerToken,
    { content: ' First comment ', author: { id: Number(admin.id) } }, 201);
  assert.equal(first.author.id, Number(reviewer.id));
  assert.equal(first.content, 'First comment');
  await call('POST', `/issues/${issue.id}/comments`, memberToken, { content: 'Second comment' }, 201);
  for (const content of [' ', 'x'.repeat(5001), null]) {
    await call('POST', `/issues/${issue.id}/comments`, memberToken, { content }, 400);
  }
  const comments = await call('GET', `/issues/${issue.id}/comments`, memberToken);
  assert.deepEqual(comments.items.map((comment) => comment.content), ['First comment', 'Second comment']);
  assert.equal((await call('GET', '/notifications', adminToken)).unreadCount, 2);
  assert.equal((await call('GET', '/notifications', memberToken)).unreadCount, 2);
});

test('notifications deduplicate reporter/assignee and exclude the actor', async () => {
  const issue = await createIssue(memberToken, Number(member.id));
  await call('POST', `/issues/${issue.id}/comments`, reviewerToken, { content: 'Please review' }, 201);
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 1);
  assert.equal((await call('GET', '/notifications', reviewerToken)).totalCount, 0);
});

test('resolution notifies a reporter who closes their own assigned issue exactly once', async () => {
  const issue = await createIssue(memberToken, Number(member.id));
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' });
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 0);
  for (let i = 0; i < 2; i++) {
    await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'CLOSED' });
  }
  const feed = await call('GET', '/notifications', memberToken);
  assert.equal(feed.totalCount, 1);
  assert.equal(feed.unreadCount, 1);
  assert.equal(feed.items[0].issueId, issue.id);
  assert.match(feed.items[0].message, /resolved/);
  assert.equal(await Notification.count({ where: { issueId: issue.id, kind: 'RESOLUTION' } }), 1);
});

test('former reporters receive and read resolution notices without regaining project access', async () => {
  const issue = await createIssue(memberToken, Number(reviewer.id));
  await call('POST', `/issues/${issue.id}/comments`, reviewerToken, { content: 'Before revocation' }, 201);
  await call('DELETE', `/projects/${project.id}/members/${member.id}`, adminToken, undefined, 204);
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'IN_PROGRESS' });
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 0);
  await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status: 'CLOSED' });
  const feed = await call('GET', '/notifications', memberToken);
  assert.equal(feed.totalCount, 1);
  assert.equal(feed.unreadCount, 1);
  assert.equal(feed.items[0].issueId, null);
  assert.match(feed.items[0].message, /resolved/);
  const notificationId = feed.items[0].id;
  for (let i = 0; i < 2; i++) {
    const read = await call('PATCH', `/notifications/${notificationId}/read`, memberToken);
    assert.equal(read.read, true);
    assert.equal(read.issueId, null);
  }
  assert.equal((await call('GET', '/notifications', memberToken)).unreadCount, 0);
  await call('GET', `/issues/${issue.id}`, memberToken, undefined, 403);
  await call('GET', `/issues/${issue.id}/comments`, memberToken, undefined, 403);
  await call('PATCH', `/notifications/${notificationId}/read`, outsiderToken, undefined, 404);
  await call('PATCH', `/notifications/${notificationId}/read`, adminToken, undefined, 404);
  await call('POST', `/projects/${project.id}/members`, adminToken, { userId: Number(member.id) }, 201);
  const restored = (await call('GET', '/notifications', memberToken)).items.find((item) => item.id === notificationId);
  assert.equal(restored.issueId, issue.id);
});

test('resolution notice stays visible if reporter membership is revoked after closure', async () => {
  const issue = await createIssue(memberToken, Number(reviewer.id));
  for (const status of ['IN_PROGRESS', 'CLOSED']) {
    await call('PATCH', `/issues/${issue.id}/status`, reviewerToken, { status });
  }
  await call('DELETE', `/projects/${project.id}/members/${member.id}`, adminToken, undefined, 204);
  const feed = await call('GET', '/notifications', memberToken);
  assert.equal(feed.totalCount, 1);
  assert.equal(feed.items[0].issueId, null);
});

test('notifications remain private and marking read is idempotent', async () => {
  await createIssue(adminToken, Number(member.id));
  const feed = await call('GET', '/notifications', memberToken);
  const id = feed.items[0].id;
  await call('PATCH', `/notifications/${id}/read`, adminToken, undefined, 404);
  await call('PATCH', `/notifications/${id}/read`, outsiderToken, undefined, 404);
  for (let i = 0; i < 2; i++) assert.equal((await call('PATCH', `/notifications/${id}/read`, memberToken)).read, true);
  assert.equal((await call('GET', '/notifications', memberToken)).unreadCount, 0);
});

test('membership removal revokes issue/comment access and hides notifications immediately', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  const notification = (await call('GET', '/notifications', memberToken)).items[0];
  await call('DELETE', `/projects/${project.id}/members/${member.id}`, adminToken, undefined, 204);
  await call('GET', `/issues/${issue.id}`, memberToken, undefined, 403);
  await call('POST', `/issues/${issue.id}/comments`, memberToken, { content: 'revoked' }, 403);
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' }, 403);
  await call('PATCH', `/notifications/${notification.id}/read`, memberToken, undefined, 403);
  assert.equal((await call('GET', '/issues', memberToken)).totalCount, 0);
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 0);
  await call('POST', `/issues/${issue.id}/comments`, reviewerToken, { content: 'after revocation' }, 201);
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 0);
});

test('project statistics reflect persistent issue states', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  await createIssue(memberToken);
  let result = await call('GET', `/projects/${project.id}`, memberToken);
  assert.equal(result.totalIssues, 2); assert.equal(result.openIssues, 2);
  for (const status of ['IN_PROGRESS', 'CLOSED']) await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status });
  result = await call('GET', `/projects/${project.id}`, memberToken);
  assert.equal(result.totalIssues, 2); assert.equal(result.openIssues, 1); assert.equal(result.closedIssues, 1);
});

test('concurrent identical status updates emit only one event', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  await Promise.all([1, 2].map(() => call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' })));
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 1);
  assert.equal((await call('GET', '/notifications', adminToken)).totalCount, 1);
});

test('concurrent closures emit a single resolution notice per reporter', async () => {
  const issue = await createIssue(memberToken, Number(member.id));
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' });
  await Promise.all([1, 2].map(() => call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'CLOSED' })));
  assert.equal((await call('GET', '/notifications', memberToken)).totalCount, 1);
});

test('a notification write failure rolls back issue state and project timestamp', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  const savedProject = await Project.findByPk(project.id);
  const original = Notification.create;
  Notification.create = async () => { throw new Error('Simulated notification failure'); };
  try {
    await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' }, 500);
  } finally { Notification.create = original; }
  assert.equal((await Issue.findByPk(issue.id)).status, 'TODO');
  assert.equal((await Project.findByPk(project.id)).updatedAt.toISOString(), savedProject.updatedAt.toISOString());
});

test('resolution notification failure rolls back closure and project timestamp', async () => {
  const issue = await createIssue(memberToken, Number(member.id));
  await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'IN_PROGRESS' });
  const savedProject = await Project.findByPk(project.id);
  const original = Notification.create;
  Notification.create = async () => { throw new Error('Simulated resolution failure'); };
  try {
    await call('PATCH', `/issues/${issue.id}/status`, memberToken, { status: 'CLOSED' }, 500);
  } finally { Notification.create = original; }
  assert.equal((await Issue.findByPk(issue.id)).status, 'IN_PROGRESS');
  assert.equal(await Notification.count({ where: { issueId: issue.id } }), 0);
  assert.equal((await Project.findByPk(project.id)).updatedAt.toISOString(), savedProject.updatedAt.toISOString());
});

test('malformed JSON and unknown endpoints return JSON errors', async () => {
  const response = await fetch(`${base}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{invalid' });
  assert.equal(response.status, 400);
  assert.equal((await response.json()).code, 'INVALID_REQUEST');
  const result = await call('GET', '/does-not-exist', memberToken, undefined, 404);
  assert.equal(result.path, '/api/does-not-exist');
});

test('initial SQL is repeatable and preserves rows, IDs and existing BCrypt hashes', async () => {
  const issue = await createIssue(adminToken, Number(member.id));
  const oldHash = (await User.findByPk(member.id)).passwordHash;
  await applySql();
  await applySql();
  assert.equal((await Issue.findByPk(issue.id)).title, issue.title);
  assert.equal((await User.findByPk(member.id)).passwordHash, oldHash);
});

test('development admin is created once and existing credentials are not reset', async () => {
  const names = ['NODE_ENV', 'ADMIN_EMAIL', 'ADMIN_PASSWORD', 'ADMIN_FULL_NAME'];
  const saved = Object.fromEntries(names.map((name) => [name, process.env[name]]));
  try {
    process.env.NODE_ENV = 'development';
    process.env.ADMIN_EMAIL = `bootstrap-${randomUUID()}@example.test`;
    process.env.ADMIN_PASSWORD = 'Original123!';
    process.env.ADMIN_FULL_NAME = 'Initial administrator';
    await bootstrapAdmin();
    const first = await User.findOne({ where: { email: process.env.ADMIN_EMAIL } });
    assert.equal(first.role, 'ADMIN');
    assert.ok(await bcrypt.compare('Original123!', first.passwordHash));
    process.env.ADMIN_PASSWORD = 'Different123!';
    await bootstrapAdmin();
    const second = await User.findByPk(first.id);
    assert.equal(second.passwordHash, first.passwordHash);
    assert.equal(await User.count({ where: { email: process.env.ADMIN_EMAIL } }), 1);
  } finally {
    for (const name of names) {
      if (saved[name] === undefined) delete process.env[name];
      else process.env[name] = saved[name];
    }
  }
});

test('explicit initializer upgrades milestone 1 without deleting existing rows', async () => {
  const legacySchema = `${schema}_legacy`;
  await sequelize.getQueryInterface().createSchema(legacySchema);
  try {
    await sequelize.transaction(async (transaction) => {
      await sequelize.query("SELECT set_config('search_path', $schema, true)", { bind: { schema: legacySchema }, transaction });
      await sequelize.query(initialSql.split('-- Milestone 2:')[0], { transaction });
    });
    const legacyUser = await User.schema(legacySchema).create({ fullName: 'Existing Spring user',
      email: 'legacy@example.test', role: 'ADMIN', passwordHash: hash.replace('$2b$', '$2a$') });
    const legacyProject = await Project.schema(legacySchema).create({ name: 'Existing project', description: 'Milestone 1 data' });
    await runInitializer(legacySchema);
    assert.equal((await User.schema(legacySchema).findByPk(legacyUser.id)).passwordHash, legacyUser.passwordHash);
    assert.equal((await Project.schema(legacySchema).findByPk(legacyProject.id)).name, 'Existing project');
    assert.equal(await Issue.schema(legacySchema).count(), 0);
    assert.equal(await Notification.schema(legacySchema).count(), 0);
  } finally {
    await sequelize.getQueryInterface().dropSchema(legacySchema);
  }
});

test('requirements migration preserves legacy data, converts only OPEN and is repeatable', async () => {
  const legacySchema = `${schema}_requirements`;
  await sequelize.getQueryInterface().createSchema(legacySchema);
  try {
    await sequelize.transaction(async (transaction) => {
      await sequelize.query("SELECT set_config('search_path', $schema, true)", { bind: { schema: legacySchema }, transaction });
      await sequelize.query(initialSql, { transaction });
    });
    const user = await User.schema(legacySchema).create({ fullName: 'Legacy reporter',
      email: 'reporter@example.test', role: 'USER', passwordHash: hash });
    const legacyProject = await Project.schema(legacySchema).create({ name: 'Legacy project', description: 'Preserve me' });
    await Membership.schema(legacySchema).create({ projectId: legacyProject.id, userId: user.id });
    const rows = [];
    for (const status of ['OPEN', 'IN_PROGRESS', 'CLOSED']) {
      const [inserted] = await sequelize.query(`INSERT INTO "${legacySchema}".issues
        (project_id, reporter_id, title, description, type, priority, status, created_at, updated_at)
        VALUES ($project, $reporter, $status, 'Keep description', 'BUG', 'HIGH', $status, now(), now()) RETURNING *`,
      { bind: { project: legacyProject.id, reporter: user.id, status } });
      rows.push(inserted[0]);
    }
    await sequelize.query(`INSERT INTO "${legacySchema}".issue_comments (issue_id, author_id, content, created_at)
      VALUES ($issue, $author, 'Keep comment', now())`, { bind: { issue: rows[0].id, author: user.id } });
    await sequelize.query(`INSERT INTO "${legacySchema}".notifications (issue_id, recipient_id, message, read, created_at)
      VALUES ($issue, $recipient, 'Keep notification', true, now())`, { bind: { issue: rows[0].id, recipient: user.id } });
    await runInitializer(legacySchema);
    await runInitializer(legacySchema);
    const migrated = await Issue.schema(legacySchema).findAll({ order: [['id', 'ASC']] });
    assert.deepEqual(migrated.map((issue) => issue.status), ['TODO', 'IN_PROGRESS', 'CLOSED']);
    for (let i = 0; i < rows.length; i++) {
      assert.equal(String(migrated[i].id), String(rows[i].id));
      assert.equal(migrated[i].title, rows[i].title);
      assert.equal(migrated[i].priority, 'HIGH');
      assert.equal(migrated[i].updatedAt.toISOString(), rows[i].updated_at.toISOString());
    }
    assert.equal((await User.schema(legacySchema).findByPk(user.id)).passwordHash, hash);
    assert.equal(await Membership.schema(legacySchema).count(), 1);
    assert.equal((await Comment.schema(legacySchema).findOne()).content, 'Keep comment');
    const notification = await Notification.schema(legacySchema).findOne();
    assert.equal(notification.kind, 'ACTIVITY');
    assert.equal(notification.read, true);
    const [created] = await sequelize.query(`INSERT INTO "${legacySchema}".issues
      (project_id, reporter_id, title, description, type, created_at, updated_at)
      VALUES ($project, $reporter, 'Without priority', 'Description', 'BUG', now(), now()) RETURNING *`,
    { bind: { project: legacyProject.id, reporter: user.id } });
    assert.equal(created[0].priority, null);
    assert.equal(created[0].status, 'TODO');
    await assert.rejects(sequelize.query(`UPDATE "${legacySchema}".issues SET status = 'OPEN'`));
  } finally {
    await sequelize.getQueryInterface().dropSchema(legacySchema);
  }
});

// Avvia un altro processo Node per verificare il vero percorso server.js e il riavvio.
async function startChild(extraEnv = {}) {
  const child = spawn(process.execPath, ['src/server.js'], { cwd: new URL('..', import.meta.url),
    env: { ...process.env, SERVER_PORT: '0', ...extraEnv }, stdio: ['ignore', 'pipe', 'pipe'] });
  let output = '';
  let errorOutput = '';
  child.stderr.on('data', (chunk) => { errorOutput += chunk; });
  const ready = new Promise((resolve, reject) => {
    child.stdout.on('data', (chunk) => {
      output += chunk;
      const match = /BugBoard26 API: http:\/\/localhost:(\d+)\/api/.exec(output);
      if (match) resolve(`http://127.0.0.1:${match[1]}/api`);
    });
    child.once('exit', (code) => reject(new Error(`Server exited ${code}: ${errorOutput}`)));
  });
  try {
    const url = await Promise.race([ready, new Promise((_, reject) => setTimeout(() => reject(new Error('Server startup timeout')), 15000).unref())]);
    return { child, url };
  } catch (error) { child.kill(); throw error; }
}

async function stopChild(child) {
  const exited = once(child, 'exit');
  child.kill();
  await exited;
}

test('server restarts preserve users, projects, issue, comment and read notification', async () => {
  const issue = await call('POST', '/issues', adminToken, imageUpload(png, 'image/png', payload(Number(member.id))), 201);
  const savedImage = (await IssueImage.findByPk(issue.id)).data;
  await call('POST', `/issues/${issue.id}/comments`, memberToken, { content: 'Persistent comment' }, 201);
  const notification = (await call('GET', '/notifications', memberToken)).items[0];
  await call('PATCH', `/notifications/${notification.id}/read`, memberToken);
  for (let restart = 0; restart < 2; restart++) {
    const { child, url } = await startChild();
    try {
      const detail = await fetch(`${url}/issues/${issue.id}`, { headers: { Authorization: `Bearer ${memberToken}` } });
      assert.equal(detail.status, 200);
      assert.equal((await detail.json()).title, issue.title);
      const image = await fetch(`${url}/issues/${issue.id}/image`, { headers: { Authorization: `Bearer ${memberToken}` } });
      assert.equal(image.status, 200);
      assert.deepEqual(Buffer.from(await image.arrayBuffer()), savedImage);
      const feed = await fetch(`${url}/notifications`, { headers: { Authorization: `Bearer ${memberToken}` } });
      assert.equal((await feed.json()).items.find((item) => item.id === notification.id).read, true);
    } finally { await stopChild(child); }
  }
  assert.equal(await Comment.count({ where: { issueId: issue.id } }), 1);
});
